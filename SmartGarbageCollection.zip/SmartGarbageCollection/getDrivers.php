<?php
require_once  'dbConnect.php';
$start = $_REQUEST['start'];
$end = $_REQUEST['end'];

if($con->connect_error)
 {
  die("Connection failed: " . $conn->connect_error); 
 }
 
$sql = "SELECT * FROM `tracking` WHERE start ='$start' AND end ='$end'";
 $result = $con->query($sql);
$Driver = array();
if ($result->num_rows > 0) {
     while($row = $result->fetch_assoc()) {
$driver = array();
				   
			      $driver["id"] = $row["id"];
			      $driver["name"]=$row["name"];
			      $driver["latitude"] = $row["latitude"];
				  $driver["longitude"] = $row["longitude"];
				  $driver["level"] = $row["level"];
			      
				  $Driver[] = $driver;
 

} 
$json['success'] = 1;
  $json['message'] ='Driver found Suceesfull';
  $json['Driver'] = $Driver;
	echo json_encode($json);
}
else {
    $json['success'] = 0;
  $json['message'] ='No Driver found';
  echo json_encode($json);

}
$con->close();
?>