 <?php
 /*   define('HOST','103.209.144.98');

 define('USER','esatta1_admin');

 define('PASS','Aphron@123');

 define('DB','esatta1_db'); */


      define('HOST','localhost');

   define('USER','root');

   define('PASS','');

   define('DB','smartgarbagecollection');
    
	$con = mysqli_connect(HOST,USER,PASS,DB);
  
  if(!$con)
  {
	  echo"not connected";
	  
  }
  else
  {
	 //echo"connected";
  }
?>