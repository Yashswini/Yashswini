<?php
$email=$_REQUEST['email'];
$password =$_REQUEST['password'];
$usertype =$_REQUEST['usertype'];
require_once('dbConnect.php');


 if($con->connect_error)
 {
  die("Connection failed: " . $con->connect_error);
 }
		 
	$sql="SELECT *
FROM `login`
WHERE email = '$email'
AND password ='$password' AND usertype='$usertype'";

    $result = $con->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
		
 $json['success'] = 1;
  $json['message'] ='Login Suceesfull';

  $json["user"]= array();
		
    while($row = $result->fetch_assoc()) {
	$user = array();
			   
		      $user["id"] = $row["id"];
		      $user["name"] = $row["name"];
			   
		      $user["email"] = $row["email"];
			  $user["password"] = $row["password"];
			  $user["usertype"] = $row["usertype"];
			   $json['user'] =$user;
 echo json_encode($json);
    }
	
} else {
    $json['success'] = 0;
  $json['message'] ='Login failed';
  echo json_encode($json);

}
$con->close();
?>