<?php
name =$_REQUEST['name'];
$emailid=$_REQUEST['emailid'];
$password=$_REQUEST['password'];
$usertype=$_REQUEST['usertype'];



require_once('dbConnect.php');

 
 //checking if the user is already exist with this username or email
 //as the email and username should be unique for every user 
 $stmt = $con->prepare("SELECT id FROM login WHERE email = '$email'");
 $stmt->execute();
 $stmt->store_result();
 
 //if the user already exist in the database 
 if($stmt->num_rows > 0){
  $json['success'] = 1;
  $json['message'] ='User alerady exists';
 
            echo json_encode($json);
 }else{

 	$stmt = $con->prepare("INSERT INTO login VALUES(null,'$name','$email','$password','$usertype')");


 if($stmt->execute()){
 
 //fetching the user back 
 $stmt = $con->prepare("SELECT id,name,emailid,password,age,height,weight,gender,mobileno,temp,bloodpressure,heartbeat,hemoglobine FROM user WHERE emailid = '$emailid'"); 
 
 $stmt->execute();
 $stmt->fetch();
 
 $user = array(
'id'=>$id, 
 'name'=>$name, 
 'email'=>$emailid,
 'password'=>$password, 
 'age'=>$age,
 'height'=>$height, 
 'weight'=>$weight,
 'gender'=>$gender, 
 'mobileno'=>$mobileno,
 'temp'=>$temp, 
 'bloodpressure'=>$bloodpressure,
 'heartbeat'=>$heartbeat,
 'hemoglobine'=>$hemoglobine
 );
 
 $stmt->close();
 
 //adding the user data in response 
 $response['error'] = false; 
 $response['message'] = 'User registered successfully'; 
 $response['user'] = $user; 
 }
 }
 
  echo json_encode($response);


?>