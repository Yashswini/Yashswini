<?php
$name =$_REQUEST['name'];
$email=$_REQUEST['email'];
$password=$_REQUEST['password'];
$usertype=$_REQUEST['usertype'];



require_once('dbConnect.php');

 
 //checking if the user is already exist with this username or email
 //as the email and username should be unique for every user 
 $stmt = $con->prepare("SELECT id FROM login WHERE email = '$email'");
 $stmt->execute();
 $stmt->store_result();
 
 //if the user already exist in the database 
 if($stmt->num_rows > 0){
  $json['success'] = "0";
  $json['message'] ='User alerady exists';
    echo json_encode($json);
 }else{

 	$stmt = $con->prepare("INSERT INTO login VALUES(null,'$name','$email','$password','$usertype')");

	$stmt->execute();
 	$stmt->close();
 
 //adding the user data in response 
  $json['success'] = "1";
  $json['message'] ='Registration sucessfull';
 echo json_encode($json);
 
 }
 
 


?>