<?php
$id =$_REQUEST['id'];
$name =$_REQUEST['name'];
$level=$_REQUEST['level'];
$latitude=$_REQUEST['latitude'];
$longitude=$_REQUEST['longitude'];
$start =$_REQUEST['start'];
$end =$_REQUEST['end'];


require_once('dbConnect.php');

 
 //checking if the user is already exist with this username or email
 //as the email and username should be unique for every user 
 $stmt = $con->prepare("SELECT id FROM tracking WHERE name = '$name' AND start = '$start' AND end = '$end'");
 $stmt->execute();
 $stmt->store_result();
 
 //if the user already exist in the database 
 if($stmt->num_rows > 0){
    $sql = "UPDATE `tracking` SET `level`= '$level',`latitude`='$latitude',`longitude`='$longitude' WHERE id = '$id'";

    if ($con->query($sql) === TRUE) {
        $message = "Record updated successfully";
    } else {
        $message = "Error updating record: " . $conn->error;
    }
    
  $json['success'] = "1";
  $json['message'] =$message;
    echo json_encode($json);
 }else{
    $stmt = $con->prepare(" INSERT INTO `tracking` (`id`, `name`, `level`, `latitude`, `longitude`, `start`, `end`) VALUES ('$id', '$name', '$level', '$latitude', '$longitude', '$start', '$end')");
    $stmt->execute();
    $stmt->close();

//adding the user data in response 
 $json['success'] = "2";
 $json['message'] ='Insert Record sucessfull';
 echo json_encode($json);
 }
 ?>