<?php
$id =$_REQUEST['id'];
require_once('dbConnect.php');


 if($con->connect_error)
 {
  die("Connection failed: " . $con->connect_error);
 }
		 
	$sql="SELECT DISTINCT `start`, `end` FROM `tracking`";

    $result = $con->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    $json['success'] = 1;
    $json['message'] ='Data Suceesfully fetched ';
  $From = array();
  
    while($row = $result->fetch_assoc()) {
    $from = array();
  
		      $from["start"]=$row["start"];
              $from["end"]=$row["end"];
              $From[] = $from;
             
    }
$json['success'] = 1;
$json['message'] ='Student found Suceesfull';
$json['from'] = $From;
echo json_encode($json);
} else {
    $json['success'] = 0;
  $json['message'] ='Login failed';
  echo json_encode($json);

}
$con->close();
?>